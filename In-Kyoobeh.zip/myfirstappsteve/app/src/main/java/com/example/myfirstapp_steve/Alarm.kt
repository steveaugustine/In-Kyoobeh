package com.example.myfirstapp_steve

import java.time.LocalDateTime

data class Alarm(val time:LocalDateTime){

}
